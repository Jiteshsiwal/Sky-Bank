<?php

// Names
define("BANKNAME", "Sky Bank");
define("EMAIL", "skybank2020@gmail.com");
define("PASSWORD", "");
define("ADDRESS", "Mumbai, India 538890");
define("MOBILENO", "+91 ");
define("LOCATION_CORDINATE", "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1859.4593645909836!2d75.29189342635094!3d21.235071092919974!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bd8df0042ddb5e9%3A0x4be13a2cd799186d!2sSmt.%20Sharadchandrika%20Suresh%20Patil%20College%20of%20Pharmacy!5e0!3m2!1sen!2sin!4v1615994468686!5m2!1sen!2sin");

// echo BANKNAME;
