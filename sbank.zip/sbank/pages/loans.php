<!DOCTYPE html>
<html lang="en">

<?php $active = "";
$title = "loans";
include "header.php" ?>

<main id="main">

  <!-- ======= Breadcrumbs ======= -->
  <section class="breadcrumbs">
    <div class="container">

      <div class="d-flex justify-content-between align-items-center">
        <ol>
          <li><a href="../">Home</a></li>
          <li>Loans</li>
        </ol>
      </div>

    </div>
  </section><!-- End Breadcrumbs -->

  <section class="inner-page">
    <div class="container">
      <h1>Loans</h1>
      <p>
        Our bank provide you the personal loan facility<br> with the very low rate of intrest per annum. Just<br> fill the online application form for personal<br> employement
        and financial details and our<br>respresentative will get in touch with you in<br> in next 24 hours.
      </p>
      <p>
        Once the verification process completed by the<br> the fund disbursal will take place in just two<br> working days.
      </p>
    </div>
  </section>

</main><!-- End #main -->

<!-- ======= Footer ======= -->

<?php
include "footer.php";
?>

</body>

</html>